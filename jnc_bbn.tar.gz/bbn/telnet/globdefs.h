/* Global defines for THP/TELNET */

#define LOGGING yes  /* Makes it use the log package */
#define NEWTTY yes   /* If you have the BBN-UNIX tty driver */
