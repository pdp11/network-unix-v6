/*
 * Define the lower-level protocol.
 * This file should contain either
 *    #define TCP true
 * or
 *    #define NCP true
 */
#define TCP true
