/*
 * dummynet - dummy network programs for loading sys25 sans net code.
 */

ncpopen() { return 0 ; }

ncpclose() { return 0 ; }

ncpread() { return 0 ; }

ncpwrite() { return 0 ; }

netopen() { return 0 ; }

netclose() { return 0 ; }

netread() { return 0 ; }

netwrite() { return 0 ; }

to_ncp() { return 0 ; }

sendins() { return 0 ; }

netstat() { return 0 ; }

