#define INHFMT "bqIIibbibbbbbbbbbbbb"
#define INHSIZE 24
#define TCPHFMT "iiLLbqIiIbbbb"
#define TCPHSIZE 24
